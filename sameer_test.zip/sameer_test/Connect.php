<?php

class Connect
{
	protected $dbname		='myglamm';
	protected $hostname		='localhost';
	protected $username		='root';	
	protected $password		='';
	protected $connect;
	function __construct()
	{
		$this->connect = mysqli_connect($this->hostname, $this->username, $this->password, $this->dbname);
	}

	public function insert_data($tbl,$data)
	{
		$col = "added_date,";
		$val = "'".date('Y-m-d')."',";
		foreach ($data as $column => $value)
		{
			$col.=$column.',';
			$val.="'".$value."',";
		}
		$col = trim($col,',');
		$val = trim($val,',');
		$sql = "INSERT INTO ".$tbl." (".$col.") values(".$val.")";
		mysqli_query($this->connect, $sql);
		return mysqli_insert_id($this->connect);
	}

	public function update_data($tbl,$data,$pkey)
	{
		$set_values='';
		foreach ($data as $column => $value)
		{
			$set_values.= "".$column."="."'".$value."',";
		}
		$set_values = trim($set_values,',');

		$sql = "UPDATE ".$tbl." SET ".$set_values." WHERE id=".$pkey;
		mysqli_query($this->connect, $sql);
		return mysqli_affected_rows($this->connect);
	}

	public function get_query_data($sql)
	{
		$data = array();
		if($result=mysqli_query($this->connect,$sql))
		{
		  	while($obj=mysqli_fetch_object($result))
		    {
		    	array_push($data, $obj);
		    }
		}
		return $data;
	}

	public function delete_data($sql)
	{
		return mysqli_query($this->connect, $sql);
	}



}

?>