<?php
require_once "Connect.php";
$db = new Connect();



if(isset($_POST['flag']) && $_POST['flag'] == 'get_data')
{
	$cust_data = $db->get_query_data("SELECT * FROM tbl_customers where id='".$_POST['id']."'");
	echo json_encode(array('success'=>true, 'msg'=>$cust_data));
}

if(isset($_POST['flag']) && $_POST['flag'] == 'get_customers')
{
	$cust_data = $db->get_query_data("SELECT * FROM tbl_customers order by id desc");
	$str='';
	$str.='
      <button class="btn btn-primary btn-xs" data-toggle="modal" onclick="open_cust_modal();">Add New</button>
      <table id="customers">
        <tr>
          <th>SrNo</th>
          <th>Name</th>
          <th>Mobile</th>
          <th>Email</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>';

        $srno=0;
        foreach ($cust_data as $key => $row)
        {
        	$srno++;
	    	$str.='
	        <tr>
	          <td>'.$srno.'</td>
	          <td>'.$row->name.'</td>
	          <td>'.$row->mobile.'</td>
	          <td>'.$row->email.'</td>
	          <td><button class="btn btn-outline-success btn-sm" onclick=get_data('.$row->id.');>Edit</button></td>
	          <td><button class="btn btn-outline-danger btn-sm" onclick=delete_data('.$row->id.');>Delete</button></td>
	        </tr>';
        }
      $str.='
      </table>';
      echo json_encode(array('success'=>true, 'msg'=>$str));
}

if(isset($_POST['flag']) && $_POST['flag'] == 'delete_data')
{
	$delete = $db->delete_data("DELETE FROM tbl_customers where id='".$_POST['id']."'");
	if($delete){
		echo json_encode(array('success'=>true, 'msg'=>"Record deleted successfully."));
	}else{
		echo json_encode(array('success'=>true, 'msg'=>"Failed to delete record."));
	}
}

if(isset($_POST['flag']) && $_POST['flag'] == 'save_customer')
{
	$data = array();
	parse_str($_POST['form_data'], $data);

	$hidden_id 				= trim(addslashes($data['hidden_id']));
	$ins_data['name'] 		= trim(addslashes($data['cust_name']));
	$ins_data['mobile'] 	= trim(addslashes($data['mobile']));
	$ins_data['email'] 		= trim(addslashes($data['email_id']));

	$error=0;
	$message='';
	if($ins_data['name'] == ''){
		$error++;
		$message.='Please enter name.<br>';
	}

	$validate_mobile = preg_match('/^[0-9]{10}+$/', $ins_data['mobile']);
	if($validate_mobile == 0){
		$error++;
		$message.='Please enter valid mobile number.<br>';
	}

	if (filter_var($ins_data['email'], FILTER_VALIDATE_EMAIL)){
	     // valid
	}else{
		$error++;
		$message.='Please enter valid email address.<br>';
	}	

	if($error==0)
	{
		if($hidden_id=='')
		{
			$cust_id = $db->insert_data("tbl_customers",$ins_data);
			if($cust_id>0){
				echo json_encode(array('success'=>true, 'msg'=>'New record inserted successfully.'));
			}else{
				echo json_encode(array('success'=>false, 'msg'=>'Failed to insert new record.'));
			}
		}else{
			$up_data['name']  = $ins_data['name'];
			$up_data['mobile'] = $ins_data['mobile'];
			$up_data['email'] = $ins_data['email'];
			$cust_id = $db->update_data("tbl_customers",$up_data,$hidden_id);
			echo json_encode(array('success'=>true, 'msg'=>'Record updated successfully.'));
		}
	}else{
		echo json_encode(array('success'=>false, 'msg'=>$message));
	}
}


?>