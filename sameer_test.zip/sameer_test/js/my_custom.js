$(document).ready(function(){
	get_customers();
	$('#customer_form').submit(function(e){
		e.preventDefault();

		var form_data = $('#customer_form').serialize();
		var formdata = {
			form_data:form_data,
			flag:'save_customer'
		};

		$.ajax({
			type: 'post',
			url : 'php_script.php',
			data:formdata,
			dataType:'json',
			success:function(resp)
			{
				if(resp.success==true){
					alert(resp.msg);
					$('#add_record_modal').modal('hide');
					get_customers();
			        $('#customer_form')[0].reset();
				}else{
					$('#errormessages').show();
					$('#errormessages').html(resp.msg);
					$('#errormessages').fadeOut(6000);
				}
			}
		});
	})
});

function get_customers()
{
	var formdata = {
		flag:'get_customers'
	};
	$.ajax({
		type: 'post',
		url : 'php_script.php',
		data:formdata,
		dataType:'json',
		success:function(resp)
		{
			$('#customer_data').html(resp.msg);
		}
	});
}

function get_data(id)
{
	$('#add_record_modal').modal('show');
	var formdata = {
		id:id,
		flag:'get_data'
	};
	$.ajax({
		type: 'post',
		url : 'php_script.php',
		data:formdata,
		dataType:'json',
		success:function(resp)
		{
			$('#hidden_id').val(resp.msg[0]['id']);
			$('#cust_name').val(resp.msg[0]['name']);
			$('#mobile').val(resp.msg[0]['mobile']);
			$('#email_id').val(resp.msg[0]['email']);
		}
	});
}

function delete_data(id)
{
	if(confirm('Are you sure, you want to delete?'))
	{
		var formdata = {
			id:id,
			flag:'delete_data'
		};
		$.ajax({
			type: 'post',
			url : 'php_script.php',
			data:formdata,
			dataType:'json',
			success:function(resp)
			{
				alert(resp.msg);
				get_customers();
			}
		});
	}
}

function open_cust_modal()
{
	$('#customer_form')[0].reset();
	$('#add_record_modal').modal('show');
}